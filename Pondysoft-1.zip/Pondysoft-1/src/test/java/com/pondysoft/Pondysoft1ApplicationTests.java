package com.pondysoft;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Pondysoft1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
