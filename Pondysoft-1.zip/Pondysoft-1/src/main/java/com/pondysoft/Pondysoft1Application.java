package com.pondysoft;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pondysoft1Application {

	public static void main(String[] args) {
		SpringApplication.run(Pondysoft1Application.class, args);
	}

}
