package com.pondysoft.service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.pondysoft.model.User;


public interface UserService 
{
	public void createUser(User user);
    public List<User> getUser();
    public User findById(long id);
    public User update(User user);
    public void deleteUserById(long id);
    public User updatePartially(User user, long id);

}
