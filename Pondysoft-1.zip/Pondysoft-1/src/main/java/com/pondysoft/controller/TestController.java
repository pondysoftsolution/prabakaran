package com.pondysoft.controller;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.pondysoft.model.User;
import com.pondysoft.service.UserService;

@RestController
public class TestController {

	@Autowired
	UserService userservice;
	@PostMapping("create")
	public ResponseEntity<?> create(@RequestBody User user) {
		userservice.createUser(user);
		List list = userservice.getUser();
		HashMap map = new HashMap();
		map.put("status", "created success");
		map.put("afterdeletedlist", list);
		return new ResponseEntity(map,HttpStatus.OK);
	}

	@PostMapping("delete")
	public ResponseEntity<?> getRegisterUser(@RequestBody String id) {
		userservice.deleteUserById(Long.valueOf(id));
		List list = userservice.getUser();
		HashMap map = new HashMap();
		map.put("status", "deleted success");
		map.put("afterdeletedlist", list);
		return new ResponseEntity(map, HttpStatus.OK);

	}

	@PostMapping("getuserbyid")
	public ResponseEntity<?> getUser(@RequestBody String id) {
		User usersdf = userservice.findById(Long.valueOf(id));
		return new ResponseEntity(usersdf, HttpStatus.OK);
	}

	@GetMapping("getalluser")
	public ResponseEntity<?> getUserList() {
		List list = userservice.getUser();
		return new ResponseEntity(list, HttpStatus.OK);
	}

	@PostMapping("update")
	public ResponseEntity<?> update(@RequestBody User user){
		User user2 = userservice.update(user);
		return new ResponseEntity(user2, HttpStatus.OK);
		
	}

}
