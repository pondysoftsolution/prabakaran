package com.pondysoft.Dao;

import java.util.List;

import com.pondysoft.model.User;

public interface UserDao {
	
public void addUser(User user);
public List<User> getUser();
public User findById(long id);
public User update(User user);
public User updateCountry(User user, long id);
public void delete(long id);
}
