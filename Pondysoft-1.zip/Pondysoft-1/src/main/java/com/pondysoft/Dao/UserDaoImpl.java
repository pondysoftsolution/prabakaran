package com.pondysoft.Dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import com.pondysoft.model.User;

@Repository
public class UserDaoImpl implements UserDao{
	@PersistenceContext
	private EntityManager entityManager;
	
	public Session getSession() {
		Session session = entityManager.unwrap(org.hibernate.Session.class);
		return session;
	}
	
	@Override
	public void addUser(User user) {
		// TODO Auto-generated method stub
		getSession().save(user);
	}

	@Override
	public List<User> getUser() {
		// TODO Auto-generated method stub
		List<User> list= getSession().createCriteria(User.class).list();
		return list;
	}

	@Override
	public User findById(long id) {
		User user=(User) getSession().get(User.class,id);// TODO Auto-generated method stub
		return user;
	}

	@Override
	public User update(User user) {
		// TODO Auto-generated method stub
		
		getSession().update(user);
		return user;
	}

	@Override
	public User updateCountry(User user, long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delete(long id) {
		User user = findById(id);
		if (user!=null) {
			getSession().delete(user);
		}
	}

}
